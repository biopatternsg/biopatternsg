base([
event('oxysterols',bind,'NR1H2'),
event('NR1H2',regulate,'CYP7A1'),
event('CYP7A1',regulate,'bile acid'),
event('bile acid',bind,'NR1H4'),
event('NR1H4',regulate,'NR0B2'),
event('NR0B2',bind,'NR5A2'),
event('NR5A2',bind,'NR0B2'),
event('NR0B2',inactivate,'CYP7A1'),
event('NR0B2',inactivate,'NR0B2'),
event('NR0B2',inhibit,'CYP7A1'),
event('NR0B2',inhibit,'NR0B2')
]).
